from setuptools import setup
setup(

	name ="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Felipe",
	author_email="luisfelipevelascotao@gmail.com",
	packages=["calculos","calculos.redonde_potencia"]
	)