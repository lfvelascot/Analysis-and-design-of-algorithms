def potencia(op1,op2):
	print ("El resultado de la potencia : ",op1," ^ ",op2," = ",op1**op2)	

def redondeo(op1):
	print ("El resultado de del redondeo de : ",op1," = ",round(op1))
